var express = require('express');
var app = express();
var path = require('path');
var bodyParser = require('body-parser');
var Gpio = require('onoff').Gpio; //include onoff to interact with the GPIO
var LED = new Gpio(4, 'out'); //use GPIO pin 4, and specify that it is output

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/static', express.static('static'));
// viewed at http://localhost:8080
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/index.html'));
});

app.post('/light', function(req, res) {
	console.log(req.body)
	let light = req.body.light;
	console.log(light)
	if(light ==='G'){		
		LED.writeSync(1);
		setTimeout(function(){
			LED.writeSync(0);
		},2000);
	}
	res.statusCode = 200;
    return res.send('POST HTTP method on user resource');
    //res.sendFile(path.join(__dirname + '/index.html'));
});

app.listen(8000);
console.log("started ....") 